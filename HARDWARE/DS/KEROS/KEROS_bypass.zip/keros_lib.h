/*
* @brief KEROS LIB Driver
*
* @note
* Copyright(C) CHIPSBRAIN CO., Ltd., 1999 ~ 2016
 * All rights reserved.
*
* File Name 	: keros_lib.h
* Author		: dennis lim
*
* Version	: V1.17
* Date 		: 2015.08.07
* Description : Keros LIB Header
*/
#ifndef __KEROS_LIB_H_
#define __KEROS_LIB_H_

#define MCU_TYPE_8BIT		0
#define MCU_TYPE_16BIT	1
#define MCU_TYPE_32BIT	2

#define MCU_TYPE	MCU_TYPE_32BIT


#ifndef uint8_t
typedef unsigned          char uint8_t;
#endif

#ifndef uint16_t
typedef unsigned short     int uint16_t;
#endif

#ifndef int16_t
typedef signed short     int int16_t;
#endif

#ifndef uint32_t
#if (MCU_TYPE == MCU_TYPE_8BIT)
typedef unsigned           long uint32_t;		// 8BIT
#endif
#if (MCU_TYPE == MCU_TYPE_16BIT)
typedef unsigned           long uint32_t;	// 16BIT
#endif
#if (MCU_TYPE == MCU_TYPE_32BIT)
typedef unsigned           int uint32_t;		// 32BIT
#endif
#endif


#ifndef NULL
#define NULL	(void*)0
#endif

#ifndef TRUE
#define TRUE	1
#endif

#ifndef FALSE
#define FALSE	0
#endif

#ifdef __cplusplus
extern "C"
{
#endif

	typedef enum {
	    KEROS_STATUS_OK = 0,
	    KEROS_STATUS_FAILED = 1,
	    KEROS_NOT_INITIALIZE_LIB = 2,
	    KEROS_NOT_SUPPORT_MODE = 3,
	    KEROS_NOT_SUPPORT_PAGE_INDEX = 4,
	    KEROS_NOT_SUPPORT_BLOCK_INDEX = 5,
	    KEROS_NOT_SUPPORT_WRITE_PAGE = 6,
	    KEROS_NOT_SUPPORT_READ_PAGE = 7,
	    KEROS_NOT_SUPPORT_CHANGE_PASSWORD_IN_PAGE = 8,
	    KEROS_FAILED_CHANGE_PASSWORD = 9,
	    KEROS_ERROR_SW_AES_ENC_DEC	= 10,
	    KEROS_NOT_MACHED_AES_KEY_SIZE = 11
	} keros_STATUS_T;


#define AES_REQ_ENCODING			0
#define AES_REQ_DECODING			1

#define SET_AES_KEY_SIZE_128		0
#define SET_AES_KEY_SIZE_192		1
#define SET_AES_KEY_SIZE_256		2

#define REQ_AES_NONE_WRITE			0
#define REQ_AES_ENCODING_WRITE		1

#define REQ_AES_NONE_READ			0
#define REQ_AES_ENCODING_READ		1

#define	MAX_EEPROM_BLOCK_NUM		16
#define 	EEPROM_BANK_LEN			64
#define 	MAX_AES_BUFFER_SIZE		16

#define	SUPPORT_STANDARD_C_LIB

extern uint8_t keros_read_data( uint16_t sub_addr, int read_len, uint8_t * r_data );
extern uint8_t keros_write_data( uint16_t sub_addr, uint8_t * w_data, int write_len );
extern void keros_delay ( uint32_t wait_time );
extern uint8_t keros_power_on( void );

	/**
	 * name : uint8_t keros_init(uint8_t *r_seral_data)
	 * @brief	: KEROS Initialize LIB
	 * @param	 r_seral_data	: Pointer to serial number of KEROS
	 * @return	On success returns KEROS_STATUS_OK.
	 *
	 */
	uint8_t keros_init( uint8_t * r_seral_data );

	/**
	 * name : uint8_t get_lib_version(uint8_t *pVer, uint8_t *len);
	 * @brief	: get information of LIB
	 * @param	 pVer : Pointer to version information of LIB
	 * @param	 len	: length to version information of LIB
	 * @return	On success returns KEROS_STATUS_OK.
	 *
	 */
uint8_t get_lib_version( uint8_t *pVer, uint8_t *len );

	/**
	 * name : uint8_t keros_page_read(uint8_t page_index, uint8_t *r_data, uint8_t is_req_decryptioned_result)
	 * @brief	: read EEPROM page data
	 * @param	 page_index : page index to read EEPROM data (0 ~ 29)
	 * @param	 r_data : pointer to read EEPROM ( mininum buffer size are 64)
	 * @param	 is_req_decryptioned_result : read data are required aes decryption.
	 *                                      0 : require raw data
	 *                                      1 : require decrypted data.
	 * @return	On success returns KEROS_STATUS_OK.
	 *            On not initialize lib returns KEROS_NOT_INITIALIZE_LIB
	 *            On page_index greate than 29 returns KEROS_NOT_SUPPORT_PAGE_INDEX
	 *            On Support Inkjet Mode and page_index less than Range Inkjet Area than returns KEROS_NOT_SUPPORT_READ_PAGE
	 *
	 */
uint8_t keros_page_read( uint8_t page_index, uint8_t *r_data, uint8_t is_req_decryptioned_result );

	/**
	 * name : uint8_t keros_page_write(uint8_t page_index, uint8_t *w_data, uint8_t is_req_encryption_to_write)
	 * @brief	: write EEPROM page data
	 * @param	 page_index : page index to write EEPROM data (0 ~ 29)
	 * @param	 r_data : pointer to read EEPROM( buffer size are 64)
	 * @param	 is_req_encryption_to_write : write data are required aes encryption.
	 *                                      0 : require raw data
	 *                                      1 : require encryption data.
	 * @return	On success returns KEROS_STATUS_OK.
	 *            On not initialize lib returns KEROS_NOT_INITIALIZE_LIB
	 *            On page_index greate than 29 returns KEROS_NOT_SUPPORT_PAGE_INDEX
	 *            On Support Inkjet Mode and page_index less than Range Inkjet Area than returns KEROS_NOT_SUPPORT_WRITE_PAGE
	 *
	 */
	uint8_t keros_page_write( uint8_t page_index, uint8_t * w_data, uint8_t is_req_encryption_to_write );

	/**
	 * name : uint8_t keros_bypass_mode(uint8_t *req_bypass_data,  uint8_t *bypassed_data);
	 * @brief	: Request Bypass Mode
	 * @param	 req_bypass_data : request source data for Bypass (must be buffer length is 16)
	 * @param	 bypassed_data : return result data for Bypass (must be buffer length is 16)
	 * @return	On success returns KEROS_STATUS_OK.
	 *            On not initialize lib returns KEROS_NOT_INITIALIZE_LIB
	 *
	 */
	uint8_t keros_bypass_mode( uint8_t * req_bypass_data, uint8_t * bypassed_data );

	/**
	 * name : uint8_t keros_power_off_nodelay(void);
	 * @brief	: power off
	 * @return	On success returns KEROS_STATUS_OK.
	 *
	 */
	uint8_t keros_power_off_nodelay( void );

	/**
	 * name : uint8_t keros_authorization(uint8_t aes_key_size, uint32_t seed, uint8_t *raw_data);
	 * @brief	: authorization
	 * @param	 aes_key_size :
         *                      SET_AES_KEY_SIZE_128
	 * 			SET_AES_KEY_SIZE_192
	 *			SET_AES_KEY_SIZE_256
	 * @param	 seed : random seed
         * @param	 raw_data : input data(must be buffer length is 16)
         * @return	TRUE : success
         *               FALSE : Fail
	 *
	 */
        uint8_t keros_authentication(uint8_t aes_key_size, uint32_t seed, uint8_t *raw_data);


#ifdef __cplusplus
}

#endif

#endif /* __KEROS_LIB_H_ */
