/*
* @brief KEROS LIB Driver
*
* @note
* Copyright(C) CHIPSBRAIN CO., Ltd., 1999 ~ 2016
 * All rights reserved.
*
* File Name 	: keros_lib.c
* Author		: dennis lim
*
* Version	: V1.17
* Date 		: 2015.08.07
* Description : Keros LIB Source
*/

//#include "stm32l0xx_hal.h"

#include "keros_lib.h"
#include "keros_interface.h"

/*****************************************************************************
 * #define
 ****************************************************************************/
#define	BYPASS_MODE_BUS					0x4000

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/
static uint8_t IsInitalizeLib = 0;

/*****************************************************************************
 * Public functions
 ****************************************************************************/

uint8_t get_lib_version( uint8_t *pVer, uint8_t *len )
{

	return KEROS_STATUS_OK;
}


uint8_t keros_page_read( uint8_t page_index, uint8_t *r_data, uint8_t is_req_decryptioned_result )
{
	return KEROS_STATUS_OK;
}

uint8_t keros_page_write( uint8_t page_index, uint8_t *w_data, uint8_t is_req_encryption_to_write )
{
	return KEROS_STATUS_OK;
}


uint8_t keros_bypass_mode( uint8_t *req_bypass_data, uint8_t *bypassed_data )
{
	if ( IsInitalizeLib == 0 ) return KEROS_NOT_INITIALIZE_LIB;

	keros_write_data( BYPASS_MODE_BUS, req_bypass_data, MAX_AES_BUFFER_SIZE );

	keros_read_data( BYPASS_MODE_BUS, MAX_AES_BUFFER_SIZE, bypassed_data );

	return KEROS_STATUS_OK;
}


uint8_t keros_set_aes_key_size( uint8_t aes_key_size )
{

	return KEROS_STATUS_OK;
}

uint8_t keros_read_inkjet_counter( uint16_t *counter_value )
{

	return KEROS_STATUS_OK;
}


uint8_t keros_inc_inkjet_counter( void )
{

	return KEROS_STATUS_OK;
}


uint8_t keros_power_off_nodelay( void )
{

	return KEROS_STATUS_OK;
}


void keros_srand( uint32_t seed )
{

}


uint8_t keros_init( uint8_t *r_seral_data )
{
	IsInitalizeLib = 1;

	return KEROS_STATUS_OK;
}

uint8_t keros_authentication(uint8_t aes_key_size, uint32_t seed, uint8_t *raw_data)
{

    return FALSE;
}


